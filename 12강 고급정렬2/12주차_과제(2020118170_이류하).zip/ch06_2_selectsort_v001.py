#!/usr/bin/python

def selectSort(A):
    ##입력: 크기가 n인 배열 A
    ##출력: 정렬된 배열 A
    ##1. for i = 0 to n-2 {
    ##2.     min = i
    ##3.     for j = i+1 to n-1 {    // A[i]~A[n-1]에서 최솟값을 찾는다.
    ##4.         if (A[j] < A[min])
    ##5.               min = j
    ##          }
    ##6.      A[i] ↔ A[min]    // min이 최솟값이 있는 원소의 인덱스
    ##    }
    ##7. return 배열 A
    A = A[:]  # 원래의 배열 리스트를 훼손하지 않은 채로,
    # 복제된 리스트를 정렬한다.
    n = len(A)

    # TODO
    for i in range(0, n-1):                 #0~끝-2까지 -> 끝-1에서 비교가 끝난다
        min = i                             #min은 0 하나 하나 비교
        for j in range(i+1, n):             #i+1~끝-1 까지

            if A[j] < A[min]:               #min요소에 최솟 값을 넣어주기위한 최솟값 j요소를 넣는다
                min = j

            A[i], A[min] = A[min], A[i]

    return A


import time
import random

if __name__ == '__main__':
    print("Selection Sort:")
    alist = random.sample(range(100), 10)
    slist = selectSort(alist)
    print("Original: ", alist)
    print("Sorted  : ", slist)
    print()
