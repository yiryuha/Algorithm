#!/usr/bin/python

def downHeap(HA, start, end):
    p = start
    left = 2 * p
    right = 2 * p + 1
    if (right <= end):  # two siblings
        if HA[left] > HA[right] and HA[left] > HA[p]:
            HA[left], HA[p] = HA[p], HA[left]
            downHeap(HA, left, end)
        elif HA[right] > HA[left] and HA[right] > HA[p]:
            HA[right], HA[p] = HA[p], HA[right]
            downHeap(HA, right, end)
        else:  # no swap
            return
    elif (left <= end):  # one siblings
        if HA[left] > HA[p]:
            HA[left], HA[p] = HA[p], HA[left]
            downHeap(HA, left, end)
        else:  # no swap
            return
    else:  # no siblings
        return


def initHeap(HA, size):
    for i in range(int(size / 2), 0, -1):
        downHeap(HA, i, size)


def heapSort(A):
    ##입력: 입력이 A[1]부터 A[n]까지 저장된 배열 A
    ##출력: 정렬된 배열 A
    ##1. 배열 A의 숫자에 대해서 힙 자료 구조를 만든다.(InitHeap 과정)
    ##2. heapSize = n    // 힙의 크기를 조절하는 변수
    ##3. for i = 1 to n-1
    ##4.      A[1] ↔ A[heapSize] // 루트와 힙의 마지막 노드 교환
    ##5.      heapSize = heapSize -1 // 힙의 크기를 1 감소
    ##6.      DownHeap()	 // 조건에 위배된 노드를 재정돈시킨다.
    ##7. return 배열 A

    A = A[:]  # 원래의 배열 리스트를 훼손하지 않은 채로,
    # 복제된 리스트를 정렬한다.
    n = len(A)
    A.insert(0, None)
    initHeap(A, n)

    ### TODO TODO
    heapSize = n
    for i in range(1, n):       #!!한 시간 동안 찾은 오류 n-1이니까..n
        A[heapSize], A[1] = A[1], A[heapSize]
        heapSize = heapSize-1
        downHeap(A, 1, heapSize)

    A.pop(0)
    return A


import time
import random

if __name__ == '__main__':
    print("Heap Sort:")
    alist = random.sample(range(100),10)
    slist = heapSort(alist)
    print("Original: ", alist)
    print("Sorted  : ", slist)
    print()
