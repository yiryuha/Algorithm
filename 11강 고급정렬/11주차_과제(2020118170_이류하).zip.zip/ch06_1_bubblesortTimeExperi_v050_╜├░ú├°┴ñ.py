#ch06_1_bubblesortTimeExperi_v050

import random
import time

def bubbleSort(A):

    A = A[:]  # 원래의 배열 리스트를 훼손하지 않은 채로,
    # 복제된 리스트를 정렬한다.
    n = len(A)

    ##1. for pass = 1 to n-1
    for pss in range(1, n):
        for i in range(1, n - pss + 1):
            if A[i - 1] > A[i]:
                A[i - 1], A[i] = A[i], A[i - 1]
    return A

def insertionSort(A):
    A = A[:]
    n = len(A)

    for i in range(1, n):
        CurrentElement = A[i]
        j = i-1
        while j >= 0 and A[j] > CurrentElement:
            A[j+1] = A[j]
            j = j-1
        A[j+1] = CurrentElement
    return A

def shellSort(A):
    A = A[:]
    n = len(A)

    h = n // 2
    while h > 0:
        for i in range(h, n):
            j = i   #j = hospit
            ce = A[i]
            while j >= h and A[j-h] > ce:
                A[j] = A[j-h]
                j=j-h
            A[j] = ce
        h//=2

    return A

def time_experiment1(N, size):                          #N, SIZE _ 200, 100 (100*5, 20*5... 1000*5)
    alist = random.sample(range(size * 5), size)        #리스트는 5*(100++)씩 증가한다

    start = time.process_time()
    for _ in range(N):                                #200만큼 반복한 측정결과
        Blist = bubbleSort(alist)
    end = time.process_time()
    print("Bubble Sort: %f sec" % (end - start))

def time_experiment2(N=200, size=100):      #똑같은 값 넘겨줌
    alist = random.sample(range(size * 5), size)

    start = time.process_time()
    for _ in range(N):
        Ilist = insertionSort(alist)
    end = time.process_time()
    print("Insert Sort: %f sec" % (end - start))

def time_experiment3(N=200, size=100):
    alist = random.sample(range(size * 5), size)

    start = time.process_time()
    for _ in range(N):
        Slist = shellSort(alist)
    end = time.process_time()
    print("ShellSort: %f sec" % (end - start))


if __name__ == '__main__':
    print("Bubble Sort:")
    alist = random.sample(range(100), 10)
    Blist = bubbleSort(alist)

    print("Original: ", alist)
    print("Sorted  : ", Blist)
    print()


    print("insertionSort:")
    alist = random.sample(range(100), 10)
    Ilist = insertionSort(alist)

    print("Original: ", alist)
    print("Sorted  : ", Ilist)
    print()

    print("ShellSort:")
    alist = random.sample(range(100), 10)
    Slist = shellSort(alist)

    print("Original: ", alist)
    print("Sorted  : ", Slist)
    print()

    for Bubble in range(100, 1001, 100):    #100 ~ 1000까지 100씩 증가시킨다
        time_experiment1(200, Bubble)

    for Insert in range(100, 1001, 100):
        time_experiment2(200, Insert)

    for Shell in range(100, 1001, 100):
        time_experiment3(200, Shell)
