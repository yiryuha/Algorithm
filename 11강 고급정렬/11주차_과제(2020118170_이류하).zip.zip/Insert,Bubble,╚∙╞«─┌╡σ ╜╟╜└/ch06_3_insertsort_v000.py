#!/usr/bin/python

def insertionSort(A):
    ##입력: 크기가 n인 배열 A
    ##출력: 정렬된 배열 A
    ##1. for i = 1 to n-1 {
    ##2.       CurrentElement = A[i]    // 정렬 안된 부분의 가장 왼쪽원소
    ##3.      j ← i – 1  // 정렬된 부분의 가장 오른쪽 원소로부터 왼쪽 방향으로 삽입할 곳을 탐색하기 위하여
    ##4.      while (j >= 0) and (A[j] > CurrentElement) {
    ##5.           A[j+1] = A[j]   // 자리 이동
    ##6.           j ← j -1
    ##          }
    ##7.       A [j+1] ← CurrentElement
    ##    }
    ##8. return A
    A = A[:]  # 원래의 배열 리스트를 훼손하지 않은 채로,
    # 복제된 리스트를 정렬한다.
    n = len(A)

    for i in range(1, n):
        CurrentElement = A[i]
        j = i-1
        while j >= 0 and A[j] > CurrentElement:
            A[j+1] = A[j]
            j = j-1
        A[j+1] = CurrentElement   #주의 A[i]번째 요소는 A[j]요소로 변경됨으로 currentelement를 미리 저장해야함

    return A


import time
import random

if __name__ == '__main__':
    print("Insertion Sort:")
    alist = random.sample(range(100), 10)
    slist = insertionSort(alist)
    print("Original: ", alist)
    print("Sorted  : ", slist)
    print()
